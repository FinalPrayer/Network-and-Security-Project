/*
 Network and Security Project - Director Side
 Header file
 */

#include "../Global/general.h"

extern int rec_reg(char *ana_type, int deviceID, char *IPaddress);
extern int network_module();
extern int ana_init();
extern int reg_check(char *anal_type);
