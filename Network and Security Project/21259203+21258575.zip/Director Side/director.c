/*
 Network and security project
 Director side.
 
 main network module.
 */

#include "director.h"

int main() {
    //straightly start the network module.
    ana_init();
    network_module();
    return 0;
}
